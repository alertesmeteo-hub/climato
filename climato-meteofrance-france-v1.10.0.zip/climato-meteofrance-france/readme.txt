=== Climatologie mensuelle Météo-France ===
Contributors: alertesmeteo
Tags: meteo, climatologie, meteo-france, station, tableau, avada
Requires at least: 5.8
Requires PHP: 7.4
Stable tag: 1.10.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Tableau de climatologie mensuelle par station officielle Météo-France : relevés jour par jour et statistiques du mois, sur tout l'historique publié par Météo-France.

== Description ==

Le shortcode [climato_meteo] affiche dans un seul module :

* le relevé quotidien du mois choisi pour une station Météo-France (Tmax, Tmin, précipitations 24h, ensoleillement) ;
* une ligne de moyennes/totaux du mois ;
* les statistiques du mois (jours de chaleur, forte/très forte chaleur, nuit tropicale, gelée, forte/très forte gelée, sans dégel, jours de pluie) ;
* un sélecteur de département, de station, de mois et d'année couvrant tout l'historique de la station (certaines stations parisiennes remontent à 1816), avec navigation mois précédent/suivant ;
* les stations fermées sont masquées par défaut (case à cocher pour les réafficher) ;
* les normales 1991-2020 et records mensuels, quand la station en publie (« Normales 1991-2020 et records »), et une comparaison du mois affiché à la normale (« Comparer avec les normales »).

Les données proviennent des fichiers publics Météo-France « Données climatologiques de base - quotidiennes » (data.gouv.fr, Licence Ouverte / Etalab 2.0) : tout l'historique publié par Météo-France pour chaque station, pas seulement les années récentes. Chaque année n'est téléchargée par le visiteur que lorsqu'il la consulte, pour rester rapide malgré l'historique complet. Comparaison aux normales 1991-2020 pas encore incluse.

== Installation ==

1. Téléversez le ZIP dans Extensions > Ajouter une extension.
2. Activez Climatologie mensuelle Météo-France.
3. Vérifiez l'URL dans Réglages > Climato Météo-France.
4. Insérez [climato_meteo] dans un bloc Avada.

Exemple : [climato_meteo departement="28" station="28198001"]

== Changelog ==

= 1.10.0 =
* Lien direct vers une station : ?station=XXXXXXXX (et facultativement &annee=AAAA&mois=M) dans l'adresse de la page ; le département est déduit de la station.

= 1.9.0 =
* Détail d'une journée : le pas de 6 minutes devient une option (boutons « Horaire » / « Toutes les 6 minutes »), l'affichage par défaut reste horaire.

= 1.8.2 =
* Panneau « Normales et records » : nouvelle palette bleue (plus de jaune).

= 1.8.1 =
* Panneau « Normales et records » : liste « Comparer avec les normales » (Aucune / 1991-2020) avec bouton OK, synchronisée avec la case à cocher du module.

= 1.8.0 =
* Panneau « Normales et records » présenté comme les fiches de référence : graphiques Tx/Tn moyennes et précipitations mensuelles, tableaux par mois avec colonne Année (températures, jours à seuil, précipitations, vent moyen, rafales, ensoleillement) et records avec dates. Nécessite la republication des normales (branche data).

= 1.7.1 =
* Correction : décocher « Comparer avec les normales » retire aussi les écarts affichés dans le tableau (seul le bilan du bas disparaissait).

= 1.7.0 =
* Graphiques du mois : températures maximales/minimales (courbes rouge/bleue) et précipitations quotidiennes (barres).
* « Comparer avec les normales » : chaque Tmax/Tmin du tableau affiche son écart à la normale du mois (rouge au-dessus, bleu en dessous) ; le bilan du mois reste affiché plus bas.
* Détail d'une journée : vent, rafale et pression arrondis.
* Bloc « Comment sont calculées ces valeurs ? » (définitions Tx/Tn/précipitations, conversion TU / heure de France).

= 1.6.0 =
* Détail d'une journée : pour un jour absent de l'archive du VPS, les relevés horaires sont demandés à l'API climatologique de Météo-France (via le VPS, avec cache).
* Jours manquants du tableau (non encore publiés dans la climatologie quotidienne, sur les ~65 derniers jours) : complétés à partir de ces relevés horaires (valeurs en italique).

= 1.5.0 =
* Détail d'une journée : relevés toutes les 6 minutes (30 derniers jours) pour le réseau synoptique principal et le département 66 ; relevés horaires pour les autres stations et les jours plus anciens.

= 1.4.1 =
* Détail d'une journée : flèche indiquant la direction du vent (sens dans lequel il souffle) avec le point cardinal.

= 1.4.0 =
* Compléments récents : les jours pas encore publiés dans la climatologie quotidienne sont complétés (en italique) avec les relevés horaires Météo-France archivés chaque heure par le VPS (Tmax, Tmin, pluie, ensoleillement).
* Détail d'une journée : un clic sur un jour affiche les relevés heure par heure (température, rosée, humidité, vent, rafales, pluie, pression, visibilité, ensoleillement) avec courbe.
* Cellules manquantes : « — » avec info-bulle expliquant que la donnée n'est pas publiée ou pas mesurée par la station.

= 1.3.1 =
* Le filtre des stations fermées fonctionne aussi avec un ancien catalogue de données v1.2.0 dépourvu du champ « active ».
* Le chargement des normales reste compatible avec les catalogues antérieurs ; la branche data doit néanmoins être reconstruite en v1.3.0 pour publier les fichiers normales.json.

= 1.3.0 =
* Les stations fermées depuis longtemps sont masquées par défaut dans le sélecteur, avec une case pour les réafficher (regroupées dans un groupe « Stations fermées »).
* Ajout des normales 1991-2020 et records mensuels (« Normales 1991-2020 et records »), sourcés depuis les fiches climatologiques Météo-France quand la station en publie une.
* Ajout de la comparaison du mois affiché à la normale (« Comparer avec les normales »), avec écart en plus/moins.

= 1.2.0 =
* Les fichiers de données volumineux (séries annuelles par station, catalogue des stations) sont désormais publiés compressés gzip pour rester sous le seuil d'alerte de taille de dépôt GitHub. Décompression native côté navigateur, aucune dépendance ajoutée. Nécessite un navigateur récent (Chrome/Edge, Firefox ou Safari à jour).

= 1.1.0 =
* Historique complet : toutes les périodes publiées par Météo-France sont désormais récupérées (jusqu'à 1816 pour certaines stations parisiennes), pas seulement les ~2 dernières années.
* Chaque station est publiée en un fichier JSON par année pour que le site ne télécharge que l'année consultée.
* Correction : le changement de département ne réinitialisait pas correctement le mois/année affiché.

= 1.0.0 =
* Première version : pipeline GitHub Actions Météo-France (data.gouv.fr) jusqu'à publication sur la branche data.
* Tableau quotidien du mois, statistiques du mois, sélection département/station/mois/année.
